#! /bin/bash
gcc kv_cache.c -o cache
chmod +x cache
./cache
